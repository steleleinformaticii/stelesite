// lgrader.cpp
#include "atena.h"
#include <cmath>
#include <iostream>
#include <vector>
#include <algorithm>
#include <cassert>
#include <tuple>
#include <utility>
#include <set>
#include <array>
#include <iomanip>

using namespace std;

int no_queries = 0;
double query(double x, double y, double r) {
    cout << "? " << setprecision(18) << fixed << x << ' ' << y << ' ' << r << '\n';
    cout.flush();
    cin >> x;
    if(x == -1) exit(0);
    return x;
}

int main() {
    
  std::vector<double> v = findCircle();
  if(v.size() != 3) {
      cout << "# 0 0 0";
      exit(0);
  }
  cout << "! " << setprecision(18) << fixed << v[0] << ' ' << v[1] << ' ' << v[2] << '\n';
  cout.flush();
  return 0;
}
